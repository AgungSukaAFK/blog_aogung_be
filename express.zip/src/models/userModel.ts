import prisma from "../lib/prismaClient";

export const UserModel = prisma.users;
